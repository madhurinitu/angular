import { Component } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-forms-app';
myForm=new FormGroup({
  firstname:new FormControl('',[Validators.required,Validators.maxLength(10),Validators.minLength(5)]),
  lastname:new FormControl('',[Validators.required,Validators.maxLength(10),Validators.minLength(5)]),
  Email:new FormControl('',[Validators.required,Validators.pattern('[A-Z0-9a-z]{5,}@[a-zA-Z0-9][.][a-z]')]),
  Contact:new FormControl('',[Validators.required,Validators.pattern('[6-9][0-9]{9}')]),
  gender:new FormControl('',[Validators.required]),
 languages:new FormControl('',[Validators.required]),
 address:new FormGroup({
 city:new FormControl('',[Validators.required]),
 state:new FormControl('',[Validators.required])
 })
});
error_messages={
  'firstname':[
  {type:'required',message:"field should not be empty"},
  {type:'maxlength',message:"characters must be 10"},
  {type:'minlength',message:"characters must be 5"},
],
  'lastname' :[
  {type:'required',message:"field should not be empty"},
  {type:'maxlength',message:"characters must be 10"}, 
  {type:'minlength',message:"characters must be 5"},

  ],
  'Email':[
    {type:'required',message:"field should not be empty"},
    {type:'[pattern',message:"enter proper format"}
  ],

    'Contact':[
      {type:'required',message:"only digits are allowed"},
      {type:'pattern',message:"enter only 10 digits"}
    ],

    'gender':[
        {type:'required',message:"field should not be empty"}],

    'languages':[
          {type:'required',message:"field should not be empty"}],
          'city':[
            {type:'required',message:"field should not be empty"}],
            'state':[
              {type:'required',message:"field should not be empty"}]
}

}
