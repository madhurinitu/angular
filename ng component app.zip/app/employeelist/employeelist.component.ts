import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {
employee=[
  {id:1,name:'raj',dept:'10',salary:9999},
  {id:2,name:'raja',dept:'20',salary:999},
  {id:3,name:'rani',dept:'30',salary:99899},
]
emp;
selectedemployee(e){
  this.emp=e;
}
  constructor() { }

  ngOnInit() {
  }

}
