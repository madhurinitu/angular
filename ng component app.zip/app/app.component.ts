import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-component-app';
maxt=10;
  tickets = 0;
  inp1=null;
  update(){
   this.maxt=this.maxt-this.tickets
  }
num;num1;num2;
  add()
  {
    this.num=this.num1+this.num2
  }
  sub()
  {
    this.num=this.num1-this.num2
  }
  Languages=[];
  Add(inp1){
  this.Languages.push(inp1);
  }
  remove(inp1){
    
    const index = this.Languages.indexOf(inp1);
this.Languages.splice(1, 2);
  }
  
@Input() telangana;
@Input() andhrapradesh;

isBordered= true;
setBorder(){
  this.isBordered=!this.isBordered;

}
d=new Date();
}
