import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
products=[
  {id:1,name:'iphone',model:'6s',price:9999},
  {id:1,name:'samsung',model:'7s',price:39999},
  {id:1,name:'oppo',model:'x',price:99999}
]
product;
slectedproduct(p){
  this.product=p;
}
  constructor() { }

  ngOnInit() {
  }

}
