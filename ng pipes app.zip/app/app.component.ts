import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ng-pipes-app';

  languages=['java','pega','react','angular','spring']
  products=[
    {id:1,name:'samsung',model:'galaxy',price:15000},
    {id:2,name:'nokia',model:'galaxybd',price:25000},
    {id:3,name:'apple',model:'x',price:85000}

  ]
}
