import { MysortPipe } from './mysort.pipe';

describe('MysortPipe', () => {
  it('create an instance', () => {
    const pipe = new MysortPipe();
    expect(pipe).toBeTruthy();
  });
});
