import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

 getAllproduct() { 
   return[
    {id:1,name:'samsung',model:'j8',price:15000},
    {id:2,name:'samsung',model:'j8',price:15000},
    {id:3,name:'samsung',model:'j8',price:15000},
    {id:4,name:'samsung',model:'j8',price:15000},
    {id:5,name:'samsung',model:'j8',price:15000},
    {id:6,name:'samsung',model:'j8',price:15000},
    {id:7,name:'samsung',model:'j8',price:15000},
    {id:8,name:'samsung',model:'j8',price:15000},
    {id:9,name:'samsung',model:'j8',price:15000},
    {id:10,name:'samsung',model:'j8',price:15000},
    {id:11,name:'samsung',model:'j8',price:15000},
    {id:12,name:'samsung',model:'j8',price:15000},
    {id:13,name:'samsung',model:'j8',price:15000},
    {id:14,name:'samsung',model:'j8',price:15000},
    {id:15,name:'samsung',model:'j8',price:15000},
    {id:16,name:'samsung',model:'j8',price:15000},
    {id:17,name:'samsung',model:'j8',price:15000},
    {id:18,name:'samsung',model:'j8',price:15000},
    {id:19,name:'samsung',model:'j8',price:15000},
    {id:20,name:'samsung',model:'j8',price:15000},
   ]
 }
 constructor(){}
}
