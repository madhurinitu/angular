import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string = 'my-ng-app';
  
  message='hello,good mrng';
  languages=['java','pega','react','angular']
  num=10;
  products=[
    {id:1,name:'iphone',model:'6s',price:9999},
    {id:2,name:'samsung',model:'note8',price:8999},
    {id:3,name:'mi',model:'note6',price:10999}
  ]
}
